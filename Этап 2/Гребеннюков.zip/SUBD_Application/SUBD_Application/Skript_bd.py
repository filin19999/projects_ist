# -*- coding: utf-8 -*-
from PyQt5 import QtCore, QtGui, QtWidgets
import sqlite3
import sys
from SUBD_MS1 import Ui_Form
from SUBD_MS2 import Ui_Form1
from SUBD_MS3 import Ui_Form2
from SUBD_MS4 import Ui_Form3
from SUBD_MS5 import Ui_Form4
from SUBD_MS6 import Ui_Form5
from SUBD_MS7 import Ui_Form6

app = QtWidgets.QApplication(sys.argv)
Form = QtWidgets.QWidget()
Form1 = QtWidgets.QWidget()
Form2 = QtWidgets.QWidget()
Form3 = QtWidgets.QWidget()
Form4 = QtWidgets.QWidget()
Form5 = QtWidgets.QWidget()
Form6 = QtWidgets.QWidget()
ui = Ui_Form()
ui1 = Ui_Form1()
ui2 = Ui_Form2()
ui3 = Ui_Form3()
ui4 = Ui_Form4()
ui5 = Ui_Form5()
ui6 = Ui_Form6()
ui6.setupUi(Form6)
ui5.setupUi(Form5)
ui4.setupUi(Form4)
ui3.setupUi(Form3)
ui2.setupUi(Form2)
ui1.setupUi(Form1)
ui.setupUi(Form)
Form.show()
def clicked_pb():
    Path_to_data_base = ui.lineEdit.text()
    Path_to_data_base = str(Path_to_data_base)
    ui.textBrowser_2.append(Path_to_data_base)
    con = sqlite3.connect(Path_to_data_base)
    cursorObj = con.cursor()
    cursorObj.execute('SELECT name from sqlite_master where type= "table"')
    pr = cursorObj.fetchall()
    ui.textBrowser_2.append(str(pr))
    con.commit()
#con = sqlite3.connect('D:\\mydatabase.db')
#cursorObj = con.cursor()
def sql_select(con):
    Path_to_data_base = ui.lineEdit.text()
    Path_to_data_base = str(Path_to_data_base)
    con = sqlite3.connect(Path_to_data_base)
    cursorObj = con.cursor()
    table = ui4.lineEdit.text()
    table = str(table)
    columns = ui4.lineEdit_2.text()
    columns = str(columns)
    condition = ui4.lineEdit_4.text()
    condition = str(condition)
    sql_columns = 'PRAGMA' + ' ' + 'table_info' + '(' + str(table) + ')'
    if str(condition) == "":
        sql_select = 'SELECT' + ' ' + str(columns) + ' ' + 'FROM' + ' ' + str(table)
    else:
        sql_select = 'SELECT' + ' ' + str(columns) + ' ' + 'FROM' + ' ' + str(table) + ' ' + 'WHERE' + ' ' + str(condition)
    ui.textBrowser_2.append(sql_select)
    cursorObj.execute(sql_select)
    pr = cursorObj.fetchall()
    cursorObj.execute(sql_columns)
    pr1 = cursorObj.fetchall()
    ui.textBrowser_2.append(str(pr1))
    ui.textBrowser.append(str(pr))
    Form4.hide()
    con.commit()
def sql_del(con):#delete table
    Path_to_data_base = ui.lineEdit.text()
    Path_to_data_base = str(Path_to_data_base)
    con = sqlite3.connect(Path_to_data_base)
    cursorObj = con.cursor()
    table = ui3.lineEdit.text()
    table = str(table)
    sql_delete = 'DROP' + ' ' + 'table' + ' ' + 'if' + ' ' + 'exists' + ' ' + str(table)
    ui.textBrowser_2.append(sql_delete)
    cursorObj.execute(sql_delete)
    con.commit()
    Form3.hide()
def create_table(con):
    Path_to_data_base = ui.lineEdit.text()
    Path_to_data_base = str(Path_to_data_base)
    con = sqlite3.connect(Path_to_data_base)
    cursorObj = con.cursor()
    name = ui1.lineEdit.text()
    name = str(name)
    columns = ui1.lineEdit_2.text()
    columns = str(columns)
    sql_create_table = 'CREATE' + ' ' + 'TABLE' + ' ' + str(name) + '(' + str(columns) + ')'
    ui.textBrowser_2.append(sql_create_table)
    cursorObj.execute(sql_create_table)
    con.commit()
def sql_update(con):
    Path_to_data_base = ui.lineEdit.text()
    Path_to_data_base = str(Path_to_data_base)
    con = sqlite3.connect(Path_to_data_base)
    cursorObj = con.cursor()
    table = ui2.lineEdit.text()
    columns = ui2.lineEdit_2.text()
    value = ui2.lineEdit_3.text()
    condition = ui2.lineEdit_4.text()
    if str(condition) == "":
        str_sql_update = 'UPDATE' + ' ' + str(table) + ' ' + 'SET' + ' ' + str(columns) + ' ' + '=' + ' ' + str(value)
    else:
        str_sql_update = 'UPDATE' + ' ' + str(table) + ' ' + 'SET' + ' ' + str(columns) + ' ' + '=' + ' ' + str(value) + ' ' + 'where' + ' ' + str(condition)
    ui.textBrowser_2.append(str_sql_update)
    Form2.hide()
    cursorObj.execute(str_sql_update)
    con.commit()
def sql_insert(con):
    Path_to_data_base = ui.lineEdit.text()
    Path_to_data_base = str(Path_to_data_base)
    con = sqlite3.connect(Path_to_data_base)
    cursorObj = con.cursor()
    table = ui6.lineEdit.text()
    columns = ui6.lineEdit_2.text()
    value = ui6.lineEdit_4.text()
    str_sql_insert = 'INSERT' + ' ' + 'INTO' + ' ' + str(table) + '(' + str(columns) + ')' + ' ' + 'VALUES' + '(' + str(value) + ')'
    ui.textBrowser_2.append(str_sql_insert)
    cursorObj.execute(str_sql_insert)
#cursorObj.execute('SELECT id, name FROM employees')
    Form6.hide()
    con.commit()
def sql_delete(con):
    Path_to_data_base = ui.lineEdit.text()
    Path_to_data_base = str(Path_to_data_base)
    con = sqlite3.connect(Path_to_data_base)
    cursorObj = con.cursor()
    table = ui5.lineEdit.text()
    #columns = ui5.lineEdit_2.text()
   # value = ui5.lineEdit_3.text()
    condition = ui5.lineEdit_4.text()
    if str(condition) == "":
        str_sql_delete = 'DELETE' + ' ' + 'FROM' + ' ' + str(table)
    else:
        str_sql_delete = 'DELETE' + ' ' + 'FROM' + ' ' + str(table) + ' ' + 'WHERE' + ' ' + str(condition)
    ui.textBrowser_2.append(str_sql_delete)
    cursorObj.execute(str_sql_delete)
    Form5.hide()
    con.commit()
def gui_push():
    Pathto_data_base = ui.lineEdit.text()
    Pathto_data_base = str(Pathto_data_base)
    if str(Pathto_data_base) == "":
        er = 'Введите путь до базы данных'
        ui.textBrowser_2.append(er)
    else:
        cst = ui.comboBox.currentText()
        if cst == 'Создать таблицу':
            Form1.show()
            ui1.pushButton.clicked.connect(create_table)
        if cst == 'Изменить данные':
            Form2.show()
            ui2.pushButton.clicked.connect(sql_update)
        if cst == 'Удалить таблицу':
            Form3.show()
            ui3.pushButton.clicked.connect(sql_del)
        if cst == 'Показать данные':
            Form4.show()
            ui4.pushButton.clicked.connect(sql_select)
        if cst == 'Удалить данные':
            Form5.show()
            ui5.pushButton.clicked.connect(sql_delete)
        if cst == 'Добавить данные':
            Form6.show()
            ui6.pushButton.clicked.connect(sql_insert)

ui.pushButton.clicked.connect(gui_push)
ui.pushButton_2.clicked.connect(clicked_pb)

entities = (2, 'Andrew', 800, 'IT', 'Tech', '2018-02-06')
#cursorObj.execute("CREATE TABLE employees(id integer PRIMARY KEY, name text, salary real, department text, position text, hireDate text)")

    ### массовая вставка:
data = [(1, "Ridesharing"), (2, "Water Purifying"), (3, "Forensics"), (4, "Botany")]
#def sql_mass_insert(con, data):
 #   cursorObj.execute('create table if not exists projects(id integer, name text)')
 #   cursorObj.executemany("INSERT INTO projects VALUES(?, ?)", data)

#con.commit()
sys.exit(app.exec_())
