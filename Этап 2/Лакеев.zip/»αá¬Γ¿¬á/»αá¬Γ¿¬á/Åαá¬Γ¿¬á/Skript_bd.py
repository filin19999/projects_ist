# -*- coding: utf-8 -*-



from PyQt5 import QtCore, QtGui, QtWidgets
import sqlite3
import sys
from TABLE_1 import Ui_Form
from TABLE_2 import Ui_Form1
from TABLE_3 import Ui_Form3
from TABLE_4 import Ui_Form4


app = QtWidgets.QApplication(sys.argv)
Form = QtWidgets.QWidget()
Form1 = QtWidgets.QWidget()
Form2 = QtWidgets.QWidget()
Form3 = QtWidgets.QWidget()
Form4 = QtWidgets.QWidget()
Form5 = QtWidgets.QWidget()
Form6 = QtWidgets.QWidget()
ui = Ui_Form()
ui1 = Ui_Form1()
ui3 = Ui_Form3()
ui4 = Ui_Form4()
ui4.setupUi(Form4)
ui3.setupUi(Form3)
ui1.setupUi(Form1)
ui.setupUi(Form)
Form.show()
def clicked_pb():
    Path_to_data_base = ui.lineEdit.text()
    Path_to_data_base = str(Path_to_data_base)
    ui.textBrowser_2.append(Path_to_data_base)
    con = sqlite3.connect(Path_to_data_base)
    cursorObj = con.cursor()
    cursorObj.execute('SELECT name from sqlite_master where type= "table"')
    pr = cursorObj.fetchall()
    ui.textBrowser_2.append(str(pr))
    con.commit()
#con = sqlite3.connect('D:\\mydatabase.db')
#cursorObj = con.cursor()
def sql_select(con):
    Path_to_data_base = ui.lineEdit.text()
    Path_to_data_base = str(Path_to_data_base)
    con = sqlite3.connect(Path_to_data_base)
    cursorObj = con.cursor()
    table = ui4.lineEdit.text()
    table = str(table)
    columns = ui4.lineEdit_2.text()
    columns = str(columns)
    sql_columns = 'PRAGMA' + ' ' + 'table_info' + '(' + str(table) + ')'
    sql_select = 'SELECT' + ' ' + str(columns) + ' ' + 'FROM' + ' ' + str(table)
    ui.textBrowser_2.append(sql_select)
    cursorObj.execute(sql_select)
    pr = cursorObj.fetchall()
    cursorObj.execute(sql_columns)
    pr1 = cursorObj.fetchall()
    ui.textBrowser_2.append(str(pr1))
    ui.textBrowser.append(str(pr))
    Form4.hide()
    con.commit()
def sql_del(con):#delete table
    Path_to_data_base = ui.lineEdit.text()
    Path_to_data_base = str(Path_to_data_base)
    con = sqlite3.connect(Path_to_data_base)
    cursorObj = con.cursor()
    table = ui3.lineEdit.text()
    table = str(table)
    sql_delete = 'DROP' + ' ' + 'table' + ' ' + 'if' + ' ' + 'exists' + ' ' + str(table)
    ui.textBrowser_2.append(sql_delete)
    cursorObj.execute(sql_delete)
    con.commit()
    Form3.hide()
def create_table(con):
    Path_to_data_base = ui.lineEdit.text()
    Path_to_data_base = str(Path_to_data_base)
    con = sqlite3.connect(Path_to_data_base)
    cursorObj = con.cursor()
    name = ui1.lineEdit.text()
    name = str(name)
    columns = ui1.lineEdit_2.text()
    columns = str(columns)
    sql_create_table = 'CREATE' + ' ' + 'TABLE' + ' ' + str(name) + '(' + str(columns) + ')'
    ui.textBrowser_2.append(sql_create_table)
    cursorObj.execute(sql_create_table)
    con.commit()
def gui_push():
    Pathto_data_base = ui.lineEdit.text()
    Pathto_data_base = str(Pathto_data_base)
    if str(Pathto_data_base) == "":
        er = 'Введите путь до базы данных'
        ui.textBrowser_2.append(er)
    else:
        cst = ui.comboBox.currentText()
        if cst == 'Создать таблицу':
            Form1.show()
            ui1.pushButton.clicked.connect(create_table)
        if cst == 'Показать данные':
            Form4.show()
            ui4.pushButton.clicked.connect(sql_select)
        if cst == 'Добавить данные':
            Form6.show()
            ui6.pushButton.clicked.connect(sql_insert)
        if cst == 'Удалить таблицу':
            Form3.show()
            ui3.pushButton.clicked.connect(sql_del)

ui.pushButton.clicked.connect(gui_push)
ui.pushButton_2.clicked.connect(clicked_pb)

entities = (2, 'Andrew', 800, 'IT', 'Tech', '2018-02-06')
#cursorObj.execute("CREATE TABLE employees(id integer PRIMARY KEY, name text, salary real, department text, position text, hireDate text)")

    ### массовая вставка:
data = [(1, "Ridesharing"), (2, "Water Purifying"), (3, "Forensics"), (4, "Botany")]
#def sql_mass_insert(con, data):
 #   cursorObj.execute('create table if not exists projects(id integer, name text)')
 #   cursorObj.executemany("INSERT INTO projects VALUES(?, ?)", data)

#con.commit()
sys.exit(app.exec_())
